Files Submitted
	- Neo_Shun_Xian_Nicholas_Assignment_1.pdf
	- Neo_Shun_Xian_Nicholas_Assignment_1.Rmd
	- raw_code_assignment_1.R

Neo_Shun_Xian_Nicholas_Assignment_1.pdf
- A formal report of Assignment 1 that is to be submitted for grading

Neo_Shun_Xian_Nicholas_Assignment_1.Rmd
- A markdown file that is used to generate Neo_Shun_Xian_Nicholas_Assignment_1.pdf

raw_code_assignment_1.R
- A file that only contains raw code for the assignment (no explanation)