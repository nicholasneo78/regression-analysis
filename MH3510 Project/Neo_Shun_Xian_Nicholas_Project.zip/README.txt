Files Submitted
	- Neo_Shun_Xian_Nicholas_Project.pdf
	- Neo_Shun_Xian_Nicholas_Project.Rmd
	- raw_code_project.R

Neo_Shun_Xian_Nicholas_Project.pdf
- A formal report of the project that is to be submitted for grading

Neo_Shun_Xian_Nicholas_Project.Rmd
- A markdown file (with codes) that is used to generate Neo_Shun_Xian_Nicholas_Project.pdf

raw_code_project.R
- A file that only contains raw code for the project (no explanation)